from .irrs_kernel_py import *

__doc__ = irrs_kernel_py.__doc__
if hasattr(irrs_kernel_py, "__all__"):
    __all__ = irrs_kernel_py.__all__